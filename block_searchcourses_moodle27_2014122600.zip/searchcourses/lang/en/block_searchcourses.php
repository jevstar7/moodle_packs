<?php
$string['pluginname'] = 'Search Courses (Autocomplete)';
$string['course_count_label'] = 'Number of Courses to show';
$string['search_label'] = 'Search:';
$string['searchcourses:addinstance'] = 'Add Search Courses block';
$string['searchcourses:myaddinstance'] = 'Add Search Courses block to My Home';
