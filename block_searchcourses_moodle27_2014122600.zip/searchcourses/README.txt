moodle-block_searchcourses
==========================
Just enter the first letter of the course you want to search and the auto complete box gives you a list of matching courses with the current word highlighted. The block also has a 'My Courses' feature, when enabled, lets you search only the courses the current user is registered on . 

This block is best used on the 'My Home' page which allows centre positioning of blocks thereby giving you a wider space to see the autocomplete results. 

 

Copyright : University of Bath
