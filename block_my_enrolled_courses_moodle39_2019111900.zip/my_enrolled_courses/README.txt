My Courses block enables users to show or hide the courses they are enrolled in. The block contains links to the courses enrolled, 
the visibility of which can be changed from the settings panel, as per requirement.  
You can hide the ones you are done with and change their visibility again, if need be. One click on a course link will redirect to that particular course page. 
It also provides quick links to the course modules in which you are enrolled.
This block can be added to any page of a Moodle site. It is perfectly compatible with Moodle versions 2.5, 2.6, 2.7, 2.8, 2.9, 3.0, 3.1, 3.2, 3.3 and 3.4.


To install, place all files in /blocks/my_courses and visit /admin/index.php in your browser.

This block is written by Dualcube <admin@dualcube.com>.
