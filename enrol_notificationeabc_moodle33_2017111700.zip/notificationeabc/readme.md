# Notificationeabc plugin

Send notifications to users when any enrolment event is executed

## Installation

1. Download Package 
2. Unzip the package inside enrol directory
4. Go to Site administration-> notifications and press "Update database now"

Compatible with moodle 3.2 and 3.3